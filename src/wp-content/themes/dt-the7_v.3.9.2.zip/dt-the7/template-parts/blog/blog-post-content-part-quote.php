<?php
/**
 * Blog quote post format content part
 *
 * @package vogue
 * @since 1.0.0
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) { exit; }

?>
		<div class="block-style-widget">
			<?php the_content(); ?>
		</div>