<?php
/**
 * Page loader template.
 */
?>
<div id="load" class="<?php echo ( isset( $load_class ) ? $load_class : '' ); ?>">
	<div class="load-wrap"><?php echo ( isset( $loader_code ) ? $loader_code : '' ); ?></div>
</div>