<?php
/**
 * Branding
 *
 */

// File Security Check
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Page definition.
 */
$options[] = array(
		"page_title"	=> _x( "Branding", "theme-options", 'the7mk2' ),
		"menu_title"	=> _x( "Branding", "theme-options", 'the7mk2' ),
		"menu_slug"		=> "of-branding-menu",
		"type"			=> "page"
);

/**
 * Heading definition.
 */
$options[] = array( "name" => _x("Branding", "theme-options", 'the7mk2'), "type" => "heading" );

/**
 * Top logo.
 */
$options[] = array(	"name" => _x('Logo in header', 'theme-options', 'the7mk2'), "type" => "block_begin" );

	// uploader
	$options[] = array(
		"name"		=> _x( 'Logo', 'theme-options', 'the7mk2' ),
		"id"		=> 'header-logo_regular',
		// full / uri_only
		"mode"		=> 'full',
		"type"		=> 'upload',
		'std'		=> array( '', 0 )
	);

	// uploader
	$options[] = array(
		"name"		=> _x( 'High-DPI (retina) logo', 'theme-options', 'the7mk2' ),
		"id"		=> 'header-logo_hd',
		// full / uri_only
		"mode"		=> 'full',
		"type"		=> 'upload',
		'std'		=> array( '', 0 )
	);

	// divider
	$options[] = array( "type" => "divider" );

	// input
	$options["header-logo_padding_top"] = array(
		"name"		=> _x( "Padding top", "theme-options", 'the7mk2' ),
		"id"		=> "header-logo_padding_top",
		"std"		=> "",
		"type"		=> "text",
		"sanitize"	=> "slider"
	);

	// divider
	$options[] = array( "type" => "divider" );

	// input
	$options["header-logo_padding_bottom"] = array(
		"name"		=> _x( "Padding bottom", "theme-options", 'the7mk2' ),
		"id"		=> "header-logo_padding_bottom",
		"std"		=> "",
		"type"		=> "text",
		"sanitize"	=> "slider"
	);

$options[] = array(	"type" => "block_end");

/**
 * Bottom logo.
 */
$options[] = array(	"name" => _x('Logo in bottom line', 'theme-options', 'the7mk2'), "type" => "block_begin" );

	// uploader
	$options[] = array(
		"name"		=> _x( 'Logo', 'theme-options', 'the7mk2' ),
		"id"		=> 'bottom_bar-logo_regular',
		"type"		=> 'upload',
		"mode"		=> 'full',
		'std'		=> array( '', 0 )
	);

	// uploader
	$options[] = array(
		"name"		=> _x( 'High-DPI (retina) logo', 'theme-options', 'the7mk2' ),
		"id"		=> 'bottom_bar-logo_hd',
		"type"		=> 'upload',
		"mode"		=> 'full',
		'std'		=> array( '', 0 )
	);

$options[] = array(	"type" => "block_end");

/**
 * Floating logo.
 */
$options[] = array(	"name" => _x('Logo in floating menu', 'theme-options', 'the7mk2'), "type" => "block_begin" );

	// radio
	$options[] = array(
		"name"		=> _x('Show logo', 'theme-options', 'the7mk2'),
		"id"		=> 'general-floating_menu_show_logo',
		"std"		=> '0',
		"type"		=> 'radio',
		"options"	=> $yes_no_options
	);

	// uploader
	$options[] = array(
		"name"		=> _x( 'Logo', 'theme-options', 'the7mk2' ),
		"id"		=> 'general-floating_menu_logo_regular',
		"type"		=> 'upload',
		"mode"		=> 'full',
		'std'		=> array( '', 0 )
	);

	// uploader
	$options[] = array(
		"name"		=> _x( 'High-DPI (retina) logo', 'theme-options', 'the7mk2' ),
		"id"		=> 'general-floating_menu_logo_hd',
		"type"		=> 'upload',
		"mode"		=> 'full',
		'std'		=> array( '', 0 )
	);

$options[] = array(	"type" => "block_end");

/////////////////
// Mobile logo //
/////////////////

// block begin
$options[] = array(	"name" => _x( 'Mobile logo', 'theme-options', 'the7mk2' ), "type" => "block_begin" );

	$options[] = array(
		"name"		=> _x( 'Logo', 'theme-options', 'the7mk2' ),
		"id"		=> 'general-mobile_logo-regular',
		"type"		=> 'upload',
		"mode"		=> 'full',
		'std'		=> array( '', 0 )
	);

	$options[] = array(
		"name"		=> _x( 'High-DPI (retina) logo', 'theme-options', 'the7mk2' ),
		"id"		=> 'general-mobile_logo-hd',
		"type"		=> 'upload',
		"mode"		=> 'full',
		'std'		=> array( '', 0 )
	);

	$options[] = array(
		"name"		=> _x( 'Padding top', 'theme-options', 'the7mk2' ),
		"id"		=> 'general-mobile_logo-padding_top',
		"std"		=> '',
		"type"		=> 'text',
		"class"		=> 'mini'
	);

	$options[] = array(
		"name"		=> _x( 'Padding bottom', 'theme-options', 'the7mk2' ),
		"id"		=> 'general-mobile_logo-padding_bottom',
		"std"		=> '',
		"type"		=> 'text',
		"class"		=> 'mini'
	);

// block end
$options[] = array(	"type" => "block_end");

/**
 * Favicon.
 */
$options[] = array(	"name" => _x('Favicon', 'theme-options', 'the7mk2'), "type" => "block_begin" );

	// uploader
	$options[] = array(
		"name"	=> _x( 'Regular (16x16 px)', 'theme-options', 'the7mk2' ),
		"id"	=> 'general-favicon',
		"type"	=> 'upload',
		'std'	=> ''
	);

	// uploader
	$options[] = array(
		"name"	=> _x( 'High-DPI (32x32 px)', 'theme-options', 'the7mk2' ),
		"id"	=> 'general-favicon_hd',
		"type"	=> 'upload',
		'std'	=> ''
	);

$options[] = array(	"type" => "block_end");

/**
 * Icons for handheld devices.
 */
$options[] = array( "name" => _x("Icons for handheld devices", "theme-options", 'the7mk2'), "type" => "block_begin" );

	// uploader
	$options["general-handheld_icon-old_iphone"] = array(
		"name"	=> _x( "60x60 px (old iPhone)", "theme-options", 'the7mk2' ),
		"id"	=> "general-handheld_icon-old_iphone",
		"type"	=> "upload",
		"std"	=> ""
	);

	// uploader
	$options["general-handheld_icon-old_ipad"] = array(
		"name"	=> _x( "76x76 px (old iPad)", "theme-options", 'the7mk2' ),
		"id"	=> "general-handheld_icon-old_ipad",
		"type"	=> "upload",
		"std"	=> ""
	);

	// uploader
	$options["general-handheld_icon-retina_iphone"] = array(
		"name"	=> _x( "120x120 px (retina iPhone)", "theme-options", 'the7mk2' ),
		"id"	=> "general-handheld_icon-retina_iphone",
		"type"	=> "upload",
		"std"	=> ""
	);

	// uploader
	$options["general-handheld_icon-retina_ipad"] = array(
		"name"	=> _x( "152x152 px (retina iPad)", "theme-options", 'the7mk2' ),
		"id"	=> "general-handheld_icon-retina_ipad",
		"type"	=> "upload",
		"std"	=> ""
	);

$options[] = array( "type" => "block_end" );

/**
 * Copyright information.
 */
$options[] = array(	"name" => _x( 'Copyright information', 'theme-options', 'the7mk2' ), "type" => "block_begin" );

	$options[] = array(
		"name"		=> _x('Copyright information', 'theme-options', 'the7mk2'),
		"id"		=> "bottom_bar-copyrights",
		"std"		=> false,
		"type"		=> 'textarea'
	);

	$options[] = array(
		"name"		=> _x( 'Give credits to Dream-Theme', 'theme-options', 'the7mk2' ),
		"id"		=> 'bottom_bar-credits',
		"type"		=> 'checkbox',
		'std'		=> 1
	);

$options[] = array(	"type" => "block_end");
